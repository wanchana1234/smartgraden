📋 วิธีใช้งานระบบเว็บแจ้งเตือน Telegram (Web App):

1. ไปที่ https://script.google.com/ แล้วสร้างโปรเจกต์ใหม่
2. สร้างไฟล์ชื่อ Code.gs และวางโค้ดจากไฟล์ Code.gs นี้
3. สร้างไฟล์ใหม่ชื่อ index.html แล้ววางเนื้อหาจากไฟล์ index.html นี้
4. กด Deploy > Test deployments หรือ "Deploy as Web App"
   - เลือก "Anyone" หรือ "Only Myself" ก็ได้
   - กด Deploy แล้วคัดลอกลิงก์ใช้งาน

✅ เมื่อเปิดหน้าเว็บ จะมีปุ่มสำหรับส่งข้อความไปยัง Telegram
